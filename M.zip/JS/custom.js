// for (let i = 0; i < menuList.length-1; i++) {
//     menuList[i].addEventListener("click",()=>{
//         menuSelect.style.display = 'flex';
//     })
// }

